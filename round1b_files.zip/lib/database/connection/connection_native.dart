// Native (Android / iOS / desktop) database connection.
// Used automatically by connection_stub.dart on any platform where
// dart:io is available. Never imported directly by app code.
import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

QueryExecutor openConnection() => _open('student_app.sqlite');

/// The separate teacher-content database (DEVIATION-23).
QueryExecutor openTeacherConnection() => _open('teacher_content.sqlite');

/// The student's own lessons, apart from the teacher panel's database.
QueryExecutor openStudentLibraryConnection() => _open('student_library.sqlite');

QueryExecutor _open(String fileName) {
  return LazyDatabase(() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, fileName));
    return NativeDatabase.createInBackground(
      file,
      setup: (rawDb) {
        rawDb.execute('PRAGMA foreign_keys = ON;');
      },
    );
  });
}
