import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../database/app_database.dart';
import '../../database/teacher_content_database.dart';
import '../../repositories/teacher_content_repository.dart';
import '../../services/planning_service.dart';
import '../../platform/connectivity.dart';
import '../../platform/page_control.dart';
import '../../services/lesson_auto_sync.dart';
import '../../services/lesson_remote_service.dart';
import '../../services/teacher_session.dart';

/// App-wide state: holds the single open database connection and the
/// current student's id (this is a single-user personal app — one
/// student per install — so we do not build a multi-student picker).
///
/// Also tracks first-run / onboarding status. Nothing here touches the
/// network; SharedPreferences is local device storage only.
class AppState extends ChangeNotifier with WidgetsBindingObserver {
  AppState._(this.db, this._studentId, {bool teacherOnly = false})
      : _teacherOnly = teacherOnly;

  /// State of the SEPARATE teacher panel (`#/teacher`). It has no student and
  /// never reads the student's database: the teacher repository gets no
  /// access to it at all (no curriculum linking), and no app-open planning
  /// runs. The student database object is created lazily and never queried.
  factory AppState.teacherPortal() =>
      AppState._(AppDatabase.open(), null, teacherOnly: true);

  final bool _teacherOnly;
  bool get isTeacherPortal => _teacherOnly;

  final AppDatabase db;
  String? _studentId;

  String? get studentId => _studentId;
  bool get hasStudent => _studentId != null;

  /// The teacher entry of this version (phase C). Local only; see
  /// TeacherSession for what it does NOT do (it cannot verify identity).
  /// The separate teacher-content database (DEVIATION-23), opened on first
  /// use so a student who never opens the library pays nothing for it.
  late final TeacherContentDatabase teacherDb = _teacherOnly
      ? TeacherContentDatabase.open()
      : TeacherContentDatabase.openStudentLibrary();

  TeacherContentRepository get teacherRepository =>
      TeacherContentRepository(teacherDb, mainDb: _teacherOnly ? null : db);

  /// Shared lesson storage (Supabase). Disabled until configured.
  late final LessonRemoteService lessonRemote = LessonRemoteService();

  /// Automatic arrival of new lessons (student side only; never started in
  /// the teacher panel). See [LessonAutoSync] for exactly when it runs.
  late final LessonAutoSync autoSync = LessonAutoSync(
    readLevel: () async {
      final raw = await SharedPrefsKeyValueStore().getString(kStudentLessonLevelKey);
      final v = int.tryParse(raw ?? '');
      return (v != null && v >= 1 && v <= 3) ? v : null;
    },
    syncLevel: (level) =>
        LessonSyncService(lessonRemote, teacherRepository).syncLevel(level),
    isConfigured: () => lessonRemote.configured,
  );

  bool _autoSyncStarted = false;

  void startAutoSync() {
    if (_teacherOnly || _autoSyncStarted) return;
    _autoSyncStarted = true;
    WidgetsBinding.instance.addObserver(this);
    autoSync.start(onlineEvents());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    autoSync.setForeground(state == AppLifecycleState.resumed);
    if (state == AppLifecycleState.resumed) unawaited(checkStorageAlive());
  }

  bool _checkingStorage = false;

  /// Phones may freeze a page's background workers while the app is away.
  /// When the student comes back, the database can then stop answering and
  /// the screens stay on their loading state («التطبيق متجمد»). A trivial
  /// query with a time limit detects this; if it does not answer, the page is
  /// reloaded, which reopens the database from what is saved on the device.
  /// Nothing is lost: everything the student entered is already stored, and an
  /// unfinished registration is kept as a draft.
  Future<void> checkStorageAlive({
    Duration limit = const Duration(seconds: 6),
    void Function()? onFrozen,
  }) async {
    if (_teacherOnly || _checkingStorage) return;
    _checkingStorage = true;
    try {
      await db.customSelect('SELECT 1').get().timeout(limit);
    } on TimeoutException {
      (onFrozen ?? reloadPage)();
    } catch (_) {
      // Any other error is a normal failure, not a freeze: leave it alone.
    } finally {
      _checkingStorage = false;
    }
  }

  /// The teacher's number for this visit (memory only).
  final TeacherRemoteSession teacherRemote = TeacherRemoteSession();

  late final TeacherSession teacherSession =
      TeacherSession(SharedPrefsKeyValueStore());

  /// The teacher's number remembered on this device (only if she chose it).
  late final TeacherSavedAccess teacherAccess =
      TeacherSavedAccess(SharedPrefsKeyValueStore());

  static const _studentIdKey = 'current_student_id';

  static Future<AppState> bootstrap() async {
    final db = AppDatabase.open();
    final prefs = await SharedPreferences.getInstance();
    final storedId = prefs.getString(_studentIdKey);

    // Defensive check: the id was saved locally but the row may not
    // actually exist anymore (e.g. app data partially cleared, or a
    // future "reset app" feature ran). Never trust the cached id blindly.
    String? verifiedId;
    if (storedId != null) {
      final row = await (db.select(db.students)
            ..where((t) => t.id.equals(storedId)))
          .getSingleOrNull();
      verifiedId = row?.id;
      if (verifiedId == null) {
        await prefs.remove(_studentIdKey);
      }
    }

    final state = AppState._(db, verifiedId);
    state.startAutoSync();

    // B: the app-open trigger of the planning service (there is no
    // background work without a server). Fire-and-forget: it never delays
    // start-up and never throws (errors are collected inside the result).
    // E: the result is now KEPT (see [lastAppOpen]) so a screen can show what
    // happened when the app was opened (D-2 Q05); before E it was discarded.
    if (verifiedId != null) {
      unawaited(state.runAppOpen());
    }

    return state;
  }

  AppOpenResult? _lastAppOpen;
  String? _lastAppOpenError;
  bool _appOpenRunning = false;

  /// What the last app-open run did (null until it finishes, or when there is
  /// no student). Written only by [runAppOpen].
  AppOpenResult? get lastAppOpen => _lastAppOpen;

  /// Set only if the run itself threw (the service normally collects errors
  /// inside the result instead of throwing).
  String? get lastAppOpenError => _lastAppOpenError;

  bool get appOpenRunning => _appOpenRunning;

  /// Runs the planning service's app-open step and keeps its result. The
  /// service decides whether anything changes (its own hysteresis); this only
  /// stores and announces the outcome. A second call while one is running is
  /// ignored.
  Future<void> runAppOpen() async {
    if (_studentId == null || _appOpenRunning) return;
    _appOpenRunning = true;
    notifyListeners();
    try {
      _lastAppOpen = await PlanningService(db).onAppOpen();
      _lastAppOpenError = null;
    } catch (e) {
      _lastAppOpenError = '$e';
    } finally {
      _appOpenRunning = false;
      notifyListeners();
    }
  }

  Future<void> setStudentId(String id) async {
    _studentId = id;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_studentIdKey, id);
    notifyListeners();
  }

  /// Forgets the current student (used by "reset all data"): the app
  /// returns to first-run onboarding.
  Future<void> clearStudent() async {
    _studentId = null;
    _lastAppOpen = null;
    _lastAppOpenError = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_studentIdKey);
    notifyListeners();
  }
}
